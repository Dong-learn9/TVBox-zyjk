var rule = Object.assign(muban.海螺3,{
title:'番茄影视',
host:'https://www.tjomet.com',
url:'/vodshow/fyclass--------fypage---.html',
searchUrl:'/vodsearch/**----------fypage---.html',
});